#!/bin/bash
#cd /root/Desktop/ascrmgui
java -jar ascrm.jar
