#!/bin/bash
rm -f *.bin *.o *.out *.*~ *~
make -f Makeso
rm -f *.bin *.o *.out *.*~ *~

