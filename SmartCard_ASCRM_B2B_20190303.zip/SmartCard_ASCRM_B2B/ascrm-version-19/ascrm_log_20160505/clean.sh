#!/bin/bash
rm -f *.bin *.o *.out *.so *.*~ *~
