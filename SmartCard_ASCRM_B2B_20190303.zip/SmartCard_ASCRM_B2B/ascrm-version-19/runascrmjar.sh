#!/bin/bash

javac -classpath ".:ASCRMApi.jar" TestAscrmB2B.java

java -cp ".:ASCRMApi.jar" TestAscrmB2B





