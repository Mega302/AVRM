rm -f *.class *.so *.*~
