#!/bin/bash
./clean.sh
make -f Makeso
#cp -f libMegaAscrmNaAPI.so /root/Desktop/AscrmNoteAcceptor
#./clean.sh
#cd /root/Desktop
#./makeascrmnajar.sh

