#!/bin/bash
./clean.sh
make -f Makefile
