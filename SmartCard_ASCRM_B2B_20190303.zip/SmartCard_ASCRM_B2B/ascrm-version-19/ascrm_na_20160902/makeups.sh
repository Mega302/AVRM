#!/bin/bash
./clean.sh
make -f Makeups
