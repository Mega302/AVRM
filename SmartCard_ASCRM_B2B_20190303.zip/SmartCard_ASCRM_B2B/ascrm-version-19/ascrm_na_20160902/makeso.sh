#!/bin/bash
rm -f *.bin *.o *.out *.*~ *~
make -f Makeso
rm -f *.bin *.o *.out *.*~ *~
#cp -f libMegaAscrmNaAPI.so /root/Desktop/AscrmNoteAcceptor
#./clean.sh
#cd /root/Desktop
#./makeascrmnajar.sh

