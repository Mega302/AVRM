
#ifndef _CollectCard_h_
#define _CollectCard_h_

#include "delaytime.h"
#include "serial.h"
#include "AcceptCard.h"




int CollectCard_c(int Timeout);


#endif


