
#ifndef _EnableCardAcceptance_h_
#define _EnableCardAcceptance_h_

#include "delaytime.h"
#include "serial.h"
#include "ConnectDevice.h"


int EnableCardAcceptance_c(int Timeout);

#endif
