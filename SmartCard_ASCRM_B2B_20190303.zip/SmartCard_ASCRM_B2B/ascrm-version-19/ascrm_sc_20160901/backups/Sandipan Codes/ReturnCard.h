
#ifndef _ReturnCard_h_
#define _ReturnCard_h_

#include "delaytime.h"
#include "serial.h"
#include "AcceptCard.h"


int ReturnCard_c(int DispenseMode,int Timeout);

#endif

