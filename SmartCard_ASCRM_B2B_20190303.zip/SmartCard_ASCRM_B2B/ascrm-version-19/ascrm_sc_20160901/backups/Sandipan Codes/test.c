
#include "ConnectDevice.h"


int main()
{

int i = ConnectDevice_c(0, 0, 0);
printf("\n[ConnectDevice_c()] Function Return Data = %d",i);

/*  
int j = AcceptCard_c(0);
printf("\n[AcceptCard_c()] Function Return Data = %d\n",j);
*/ 

/*
int g = EnableCardAcceptance_c(0);
printf("\n[EnableCardAcceptance_c()] Function Return Data = %d\n",g);
*/

/* 
int q = DisableCardAcceptance_c(0);
printf("\n[DisableCardAcceptance_c()] Function Return Data = %d\n",q);
*/ 

/*
int q = DispenseCard_c(0);
printf("\n[DispenseCard_c()] Function Return Data = %d\n",q);
*/

/*
int p = ReturnCard_c(0,0);
printf("\n[ReturnCard_c()] Function Return Data = %d\n",p);
*/

/*
int y = RejectCard_c(0);
printf("\n[RejectCard_c()] Function Return Data = %d\n",y);
*/

/*
int w = IsCardInChannel_c(0);
printf("\n[IsCardInChannel_c()] Function Return Data = %d\n",w);
*/

/*
int a = IsCardRemoved_c(0);
printf("\n[IsCardRemoved_c()] Function Return Data = %d\n",a);
*/

/*
int r = DisConnectDevice_c(0);
printf("\n[DisConnectDevice_c()] Function Return Data = %d\n",r);
*/

}
