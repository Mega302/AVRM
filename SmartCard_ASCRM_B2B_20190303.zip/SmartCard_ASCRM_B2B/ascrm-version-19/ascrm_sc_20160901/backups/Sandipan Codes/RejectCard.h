
#ifndef _RejectCard_h_
#define _RejectCard_h_

#include "delaytime.h"
#include "serial.h"
#include "AcceptCard.h"






int RejectCard_c(int Timeout);


#endif


