
#ifndef _DisableCardAcceptance_h_
#define _DisableCardAcceptance_h_

#include "delaytime.h"
#include "serial.h"
#include "ConnectDevice.h"


int DisableCardAcceptance_c(int Timeout);

#endif
