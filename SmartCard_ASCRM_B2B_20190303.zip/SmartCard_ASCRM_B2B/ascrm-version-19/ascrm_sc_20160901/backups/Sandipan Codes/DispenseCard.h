
#ifndef _DispenseCard_h_
#define _DispenseCard_h_

#include "delaytime.h"
#include "serial.h"
#include "ConnectDevice.h"

int DispenseCard_c(int Timeout);

#endif
