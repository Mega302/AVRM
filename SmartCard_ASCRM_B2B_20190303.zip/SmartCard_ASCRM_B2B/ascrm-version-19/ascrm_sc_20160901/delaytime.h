#ifndef _delaytime_h_
#define _delaytime_h_

#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

void  delay_mSec(const int milisec);

#endif

