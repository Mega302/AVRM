#!/bin/bash
./clean.sh
make -f Makeso
#cp -f libMegaAscrmScAPI.so /root/Desktop/AscrmSmartcard
#./clean.sh
#cd /root/Desktop
#./makeascrmscjar.sh

