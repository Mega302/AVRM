

import org.usb4java.Context;
import org.usb4java.Device;
import org.usb4java.DeviceDescriptor;
import org.usb4java.DeviceList;
import org.usb4java.LibUsb;
import org.usb4java.LibUsbException;
import org.usb4java.DeviceHandle;
import org.usb4java.DeviceDescriptor;
import org.usb4java.ConfigDescriptor;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

/**
 * Simply lists all available USB devices.
 * 
 * @author Klaus Reimer <k@ailis.de>
 */

//Bus 001 Device 005: ID 0483:5740 STMicroelectronics STM32F407

public class ListDevices
{
    /**
     * Main method.
     * 
     * @param args
     *            Command-line arguments (Ignored)
     */
       public static void main(String[] args)
       {
 	                int interfaceNumber=1;
                       
                        // Create the libusb context
			Context context = new Context();
		
			 // Initialize the libusb context
			int result = LibUsb.init(context);
			if (result < 0)
			{
			    System.out.println("Unable to initialize libusb");
                            return;
			    
			}  
   
                        Device device = findDevice((short)0x0483,(short)0x5740); 

                        DeviceHandle handle = new DeviceHandle();
			result = LibUsb.open(device, handle);
			if (result != LibUsb.SUCCESS)
                        {
                              System.out.println("Unable to open USB device");
                              return;
                        }
			try
			{
			        // Use device handle here
                                System.out.println("Successfully open USB device");
                                // Dump all configuration descriptors
                                final DeviceDescriptor descriptor = new DeviceDescriptor();
                                result = LibUsb.getDeviceDescriptor(device, descriptor);
				if (result < 0)
				{
				    System.out.println("Unable to read device descriptor");
				}
                                
                                //dumpConfigurationDescriptors(device, descriptor.bNumConfigurations());

                                // Check if kernel driver must be detached
                                boolean value1 = LibUsb.hasCapability(LibUsb.CAP_SUPPORTS_DETACH_KERNEL_DRIVER);

                                int value2 = LibUsb.kernelDriverActive(handle, interfaceNumber);

				boolean detach = true ;

				// Detach the kernel driver
				if (detach)
				{
				    result = LibUsb.detachKernelDriver(handle,  interfaceNumber);
				    if (result != LibUsb.SUCCESS) 
                                    {
                                       System.out.println("Unable to detach kernel driver"); 
                                       //return;
                                    }
                                      
				}


                                result = LibUsb.claimInterface(handle, interfaceNumber);

				if (result != LibUsb.SUCCESS) 
                                { 
                                      System.out.println("Unable to claim interface");
                                      return;
                                }
				try
				{
				       //Use interface here
                                        System.out.println("Successfully claim interface");
                                        
                                        String text="HelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrldHelloWOrld";

                                        ByteBuffer buffer = ByteBuffer.allocateDirect(text.getBytes().length);
 
					buffer.put(text.getBytes());
				 
					IntBuffer transfered = IntBuffer.allocate(3);

                                        byte endpoint =(byte)0x03;
				 
					 result = LibUsb.bulkTransfer(handle, endpoint, buffer, transfered, 3000);
				 
					if (result != LibUsb.SUCCESS) {
					    System.out.println("EXCEPTION THROWN");
					    //return false;
					}
				 
					System.out.println(transfered.get() + " bytes sent");
					
					
					
				}
				finally
				{
				    
				}

                                

                                result = LibUsb.releaseInterface(handle, interfaceNumber);

				if (result != LibUsb.SUCCESS) 
                                {
                                  System.out.println("Unable to release interface");
                                }
                                else
                                  System.out.println("Successfully release interface");

                                // Attach the kernel driver again if needed
				if (detach)
				{
				    result = LibUsb.attachKernelDriver(handle,  interfaceNumber);
				    if (result != LibUsb.SUCCESS) System.out.println("Unable to re-attach kernel driver");
                                    else System.out.println("Successfully re-attach kernel driver");
				}
                                LibUsb.close(handle);
                            
			}
			finally
			{
			    
			}

                        

			// Deinitialize the libusb context
			LibUsb.exit(context);

       }//public static void main(String[] args) ends

       public static void dumpConfigurationDescriptors(final Device device,final int numConfigurations)
       {
		for (byte i = 0; i < numConfigurations; i += 1)
		{
		    final ConfigDescriptor descriptor = new ConfigDescriptor();
		    final int result = LibUsb.getConfigDescriptor(device, i, descriptor);
		    if (result < 0)
		    {
		        throw new LibUsbException("Unable to read config descriptor",
		            result);
		    }
		    try
		    {
		        System.out.println(descriptor.dump().replaceAll("(?m)^",
		            "  "));
		    }
		    finally
		    {
		        // Ensure that the config descriptor is freed
		        LibUsb.freeConfigDescriptor(descriptor);
		    }
		}
       
       }

       public void ListDevice()
       {
                        // Create the libusb context
			Context context = new Context();
		
			 // Initialize the libusb context
			int result = LibUsb.init(context);
			if (result < 0)
			{
			    throw new LibUsbException("Unable to initialize libusb", result);
			    
			}

			// Read the USB device list
			DeviceList list = new DeviceList();
			result = LibUsb.getDeviceList(context, list);
			if (result < 0)
			{
			    throw new LibUsbException("Unable to get device list", result);
			}

			try
			{
			    // Iterate over all devices and list them
			    for (Device device: list)
			    {
				int address = LibUsb.getDeviceAddress(device);
				int busNumber = LibUsb.getBusNumber(device);
				DeviceDescriptor descriptor = new DeviceDescriptor();
				result = LibUsb.getDeviceDescriptor(device, descriptor);
				if (result < 0)
				{
				    throw new LibUsbException("Unable to read device descriptor", result);
				   
				}
				System.out.format(
				    "Bus %03d, Device %03d: Vendor %04x, Product %04x%n",
				    busNumber, address, descriptor.idVendor(),
				    descriptor.idProduct());
			    }
			}
			finally
			{
			    // Ensure the allocated device list is freed
			    LibUsb.freeDeviceList(list, true);
			}

			// Deinitialize the libusb context
			LibUsb.exit(context);
        
        }//public void ListDevice() end

        public static Device findDevice(short vendorId, short productId)
	{
	    // Read the USB device list
	    DeviceList list = new DeviceList();
	    int result = LibUsb.getDeviceList(null, list);
	    if (result < 0) throw new LibUsbException("Unable to get device list", result);

	    try
	    {
		// Iterate over all devices and scan for the right one
		for (Device device: list)
		{
		    DeviceDescriptor descriptor = new DeviceDescriptor();
		    result = LibUsb.getDeviceDescriptor(device, descriptor);
                    System.out.format(
				    " Vendor %04x, Product %04x%n",
				    descriptor.idVendor(),
				    descriptor.idProduct());
		    if (result != LibUsb.SUCCESS) throw new LibUsbException("Unable to read device descriptor", result);
		    if (descriptor.idVendor() == vendorId && descriptor.idProduct() == productId) 
                    {
                        System.out.println("Device Found");
                        return device;
                    }
		}
	    }
	    finally
	    {
		// Ensure the allocated device list is freed
		LibUsb.freeDeviceList(list, true);
	    }

	    // Device not found
	    return null;
	}
 
}
